﻿using System;
using System.Collections.Generic;
using SFML.System;
using SFML.Graphics;
using SFML.Window;

namespace Engine
{
    // public class Button
    // {
    //     Vector2f coords;
    //     Vector2f textCoords;
    //     Vector2f size;
    //     Color color;
    //     Color activeColor;
    //     Color colorTitle;
    //     Color activeColorTitle;
    //     Vector2f hitBox;
    //     Font font = Game.Font;
    //     Text text;
    //     Text letter;
    //     string message;
    //     uint fontSize;
    //     int alreadyPressed;
    //     uint center;
    //     bool aim;
    //     bool check;
    //     bool buttonPressed;
    //     float textLength;
    //     float letterLength;
    // 
    //     public Button(Vector2f coords, Vector2f size,
    //         Color color, Color activeColor, Color colorTitle, Color activeColorTitle,
    //         Vector2f hitBox, string message = "",
    //         uint fontSize = 20, int alreadyPressed = 120,
    //         uint center = 0, bool aim = false, bool check = true, bool automaticalOptimisationSize = true)
    //     {
    //         this.center = center;
    //         this.message = message;
    // 
    //         this.textCoords = coords;
    // 
    //         if (!automaticalOptimisationSize) this.fontSize = fontSize;
    //         else this.fontSize = (uint)(Program.resolution.Y / (1080 / fontSize));
    // 
    //         this.text = new Text(this.message, this.font, this.fontSize);
    //         this.letter = new Text("A", this.font, this.fontSize);
    //         this.letterLength = letter.GetLocalBounds().Width;
    //         this.textLength = this.text.GetLocalBounds().Width;
    // 
    //         if (hitBox != new Vector2f(0, 0)) this.hitBox = hitBox;
    //         else this.hitBox = new Vector2f(-this.letterLength, -fontSize / 4);
    // 
    //         if (size != new Vector2f(0, 0)) this.size = size;
    //         else 
    //         {
    //             this.size = new Vector2f(this.textLength, this.fontSize * 2); 
    //         }
    // 
    //         switch (this.center)
    //         {
    //             case 0:
    //                 this.coords = coords;
    //                 break;
    //             case 1:
    //                 this.coords = new Vector2f(coords.X - this.size.X / 2, coords.Y);
    //                 break;
    //             case 2:
    //                 this.coords = new Vector2f(coords.X - this.size.X - 2 * hitBox.X, coords.Y);
    //                 break;
    //         }
    //         this.coords.X += this.hitBox.X;
    //         this.size.X -= 2 * this.hitBox.X;
    // 
    //         this.color = color;
    //         this.activeColor = activeColor;
    //         this.colorTitle = colorTitle;
    //         this.activeColorTitle = activeColorTitle;
    //         this.alreadyPressed = alreadyPressed;
    //         this.aim = aim;
    //         this.check = check;
    //         this.buttonPressed = false;
    //     }
    // 
    //     public Button(string message, Vector2f coords, Vector2f size,
    //         Color color, Color activeColor, Color colorTitle, Color activeColorTitle,
    //         Vector2f hitBox,
    //         uint fontSize = 20, int alreadyPressed = 120,
    //         uint center = 0, bool aim = false, bool check = true, bool automaticalOptimisationSize = true)
    //     {
    //         this.center = center;
    //         this.message = message;
    // 
    //         this.textCoords = coords;
    // 
    //         if (!automaticalOptimisationSize) this.fontSize = fontSize;
    //         else this.fontSize = (uint)(Program.resolution.Y / (1080 / fontSize));
    // 
    //         this.text = new Text(this.message, this.font, this.fontSize);
    //         this.letter = new Text("A", this.font, this.fontSize);
    //         this.letterLength = letter.GetLocalBounds().Width;
    //         this.textLength = this.text.GetLocalBounds().Width;
    // 
    //         if (hitBox != new Vector2f(0, 0)) this.hitBox = hitBox;
    //         else this.hitBox = new Vector2f(-this.letterLength, -fontSize / 4);
    // 
    //         if (size != new Vector2f(0, 0)) this.size = size;
    //         else
    //         {
    //             this.size = new Vector2f(this.textLength, this.fontSize * 2);
    //         }
    // 
    //         switch (this.center)
    //         {
    //             case 0:
    //                 this.coords = coords;
    //                 break;
    //             case 1:
    //                 this.coords = new Vector2f(coords.X - this.size.X / 2, coords.Y);
    //                 break;
    //             case 2:
    //                 this.coords = new Vector2f(coords.X - this.size.X - 2 * hitBox.X, coords.Y);
    //                 break;
    //         }
    //         this.coords.X += this.hitBox.X;
    //         this.size.X -= 2 * this.hitBox.X;
    // 
    //         this.color = color;
    //         this.activeColor = activeColor;
    //         this.colorTitle = colorTitle;
    //         this.activeColorTitle = activeColorTitle;
    //         this.alreadyPressed = alreadyPressed;
    //         this.aim = aim;
    //         this.check = check;
    //         this.buttonPressed = false;
    //     }
    // 
    //     public bool Draw(RenderWindow rw)
    //     {
    //         bool click = Mouse.IsButtonPressed(Mouse.Button.Left);
    //         Vector2i mouseCoords = Mouse.GetPosition(rw);
    // 
    //         if (this.color.A != 0) this.Rectangle(rw);
    //         rw.PrintText(this.message, this.textCoords, this.fontSize, this.colorTitle, this.font, this.center);
    //         if (this.alreadyPressed <= 0)
    //         {
    //             if (this.coords.X < mouseCoords.X && mouseCoords.X < this.coords.X + this.size.X && this.coords.Y < mouseCoords.Y && mouseCoords.Y < this.coords.Y + this.size.Y)
    //             {
    //                 if (!this.aim)
    //                 {
    //                     if (this.activeColor.A != 0) this.Rectangle(rw);
    //                     if (this.activeColorTitle.A != 0) rw.PrintText(this.message, this.textCoords, this.fontSize, this.activeColorTitle, this.font, this.center);
    //                     else rw.PrintText(this.message, this.textCoords, this.fontSize, this.colorTitle, this.font, this.center);
    // 
    //                     if (this.check)
    //                     {
    //                         if (click)
    //                         {
    //                             if (!this.buttonPressed)
    //                             {
    //                                 this.buttonPressed = true;
    //                                 return false;
    //                             }
    //                         }
    //                         else
    //                         {
    //                             if (this.buttonPressed)
    //                             {
    //                                 this.buttonPressed = false;
    //                                 return true;
    //                             }
    //                         }
    //                     }
    //                     else
    //                     {
    //                         if (click)
    //                         {
    //                             return true;
    //                         }
    //                     }
    //                 }
    //                 else
    //                 {
    //                     if (this.check)
    //                     {
    //                         this.buttonPressed = !this.buttonPressed;
    //                         return true;
    //                     }
    //                     return false;
    //                 }
    //             }
    //             else
    //             {
    //                 this.buttonPressed = false;
    //                 return false;
    //             }
    //         }
    //         else
    //         {
    //             this.alreadyPressed -= 1;
    //             return false;
    //         }
    //         return false;
    //     }
    // 
    //     public void Rectangle(RenderWindow rw)
    //     {
    //         RectangleShape rect = new RectangleShape();
    //         rect.Position = this.coords;
    //         rect.Size = this.size;
    //         rect.FillColor = this.color;
    //         rw.Draw(rect);
    //     }
    // 
    //     public void changeColor(Color color)
    //     {
    //         this.color = color;
    //         this.activeColor = new Color(0, 0, 0, 0);
    //         this.colorTitle = new Color((byte)(color.R + 25), (byte)(color.G + 25), (byte)(color.B + 25), (byte)(color.A + 50));
    //         this.activeColorTitle = new Color(0, 0, 0, 0);
    //     }
    // 
    //     public void secondChange(Color color, Color activeColor, Color colorTitle, Color activeColorTitle)
    //     {
    //         this.color = color;
    //         this.activeColor = activeColor;
    //         this.colorTitle = colorTitle;
    //         this.activeColorTitle = activeColorTitle;
    //     }
    // }

    public abstract class Button : IDrawable
    {
        public bool ButtonPressed { get; protected set; }

        protected Vector2f coords;
        protected Vector2f textCoords;
        protected Vector2f size;
        protected Color color;
        protected Color colorTitle;
        protected Vector2f hitbox;
        protected Font font = new("files/font/ArialRegular.ttf");
        protected string message = "";
        protected uint fontSize;
        protected uint delay;
        protected bool buttonPressed;
        protected float textLength;
        protected float letterLength;

        protected Button(Vector2f Resolution, Vector2f OriginalResolution, string message, Vector2f coords, Vector2f size, Color color, Color colorTitle, Vector2f hitbox,
            string font = "", uint fontSize = 20, uint delay = 120, byte center = 0, bool automaticalOptimizationSize = true)
        {
            this.message = message;

            if (!(font == "")) this.font = new(font);

            if (automaticalOptimizationSize) this.fontSize = (uint)(Resolution.Y * fontSize / OriginalResolution.Y);
            else this.fontSize = fontSize;

            this.textLength = new Text(this.message, this.font, this.fontSize).GetLocalBounds().Width;
            this.letterLength = new Text("A", this.font, this.fontSize).GetLocalBounds().Width;

            if (hitbox == new Vector2f(0, 0)) this.hitbox = new Vector2f(-this.letterLength, 0);
            else this.hitbox = hitbox;

            if (size == new Vector2f(0, 0)) this.size = new Vector2f(this.textLength, this.fontSize * 2);
            else this.size = size;

            switch (center)
            {
                case 0: this.coords = coords; break;
                case 1: this.coords = new Vector2f(coords.X - this.size.X / 2, coords.Y); break;
                case 2: this.coords = new Vector2f(coords.X - this.size.X, coords.Y); break;
                default: throw new ArgumentException("Centered can be 0, 1 or 2 what means left, center, and right");
            }

            this.textCoords = coords;

            this.coords += this.hitbox;
            this.size -= 2 * this.hitbox;

            this.color = color;
            this.colorTitle = colorTitle;
            this.delay = delay;
            this.buttonPressed = false;
            this.ButtonPressed = false;
        }

        public abstract void Draw(RenderWindow rw);

        public abstract void Update(RenderWindow rw);

        protected bool Find(Vector2f mouse)
        {
            if(this.coords.X < mouse.X && mouse.X < this.coords.X + this.size.X && this.coords.Y < mouse.Y && mouse.Y < this.coords.Y + this.size.Y)
            {
                return true;
            }
            return false;
        }

        public void changeColor(Color color)
        {
            this.color = color;
        }

        public void changeColor(Color color, Color colorTitle)
        {
            this.color = color;
            this.colorTitle = colorTitle;
        }
    }
}
